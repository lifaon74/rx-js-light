import { IObservable } from '../../../../../../type/observable.type';
import { IObservablePipe } from '../../../../../type/observable-pipe.type';
import { IThenInNotifications } from '../../then-observable';
import { IThenObservableOnRejected } from '../../then-observable-on-rejected.type';
import { IRejectedObservableOutNotifications, rejectedObservable } from './rejected-observable';

export function rejectedObservablePipe<GInNextValue, GOut>(
  onRejected: IThenObservableOnRejected<GOut>,
): IObservablePipe<IThenInNotifications<GInNextValue>, IRejectedObservableOutNotifications<GInNextValue, GOut>> {
  return (subscribe: IObservable<IThenInNotifications<GInNextValue>>): IObservable<IRejectedObservableOutNotifications<GInNextValue, GOut>> => {
    return rejectedObservable<GInNextValue, GOut>(subscribe, onRejected);
  };
}
