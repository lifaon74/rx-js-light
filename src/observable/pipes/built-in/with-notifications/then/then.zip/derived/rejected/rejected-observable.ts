import { STATIC_COMPLETE_NOTIFICATION } from '../../../../../../../misc/notifications/built-in/complete/complete-notification.constant';
import { ICompleteNotification } from '../../../../../../../misc/notifications/built-in/complete/complete-notification.type';
import { createNextNotification } from '../../../../../../../misc/notifications/built-in/next/create-next-notification';
import { INextNotification } from '../../../../../../../misc/notifications/built-in/next/next-notification.type';
import { fromArray } from '../../../../../../built-in/from/without-notifications/iterable/from-array/from-array';
import { IObservable } from '../../../../../../type/observable.type';
import { IThenInNotifications, thenObservable } from '../../then-observable';
import { IThenObservableOnRejected } from '../../then-observable-on-rejected.type';

export type IRejectedObservableFulfilledNotifications<GInNextValue> =
  INextNotification<GInNextValue>
  | ICompleteNotification;

export type IRejectedObservableOutNotifications<GInNextValue, GOut> =
  GOut
  | IRejectedObservableFulfilledNotifications<GInNextValue>;

export function rejectedObservable<GInNextValue, GOut>(
  subscribe: IObservable<IThenInNotifications<GInNextValue>>,
  onRejected: IThenObservableOnRejected<GOut>,
): IObservable<IRejectedObservableOutNotifications<GInNextValue, GOut>> {
  return thenObservable<GInNextValue, IRejectedObservableOutNotifications<GInNextValue, GOut>>(
    subscribe,
    (value: GInNextValue): IObservable<IRejectedObservableFulfilledNotifications<GInNextValue>> => {
      return fromArray([
        createNextNotification(value),
        STATIC_COMPLETE_NOTIFICATION,
      ]);
    },
    onRejected,
  );
}
