import { IObservable } from '../../../../../../type/observable.type';
import { IObservablePipe } from '../../../../../type/observable-pipe.type';
import { IThenInNotifications } from '../../then-observable';
import { IThenObservableOnFulfilled } from '../../then-observable-on-fulfilled.type';
import { fulfilledObservable, IFulfilledObservableOutNotifications } from './fulfilled-observable';

export function fulfilledObservablePipe<GInNextValue, GOut>(
  onFulfilled: IThenObservableOnFulfilled<GInNextValue, GOut>,
): IObservablePipe<IThenInNotifications<GInNextValue>, IFulfilledObservableOutNotifications<GOut>> {
  return (subscribe: IObservable<IThenInNotifications<GInNextValue>>): IObservable<IFulfilledObservableOutNotifications<GOut>> => {
    return fulfilledObservable<GInNextValue, GOut>(subscribe, onFulfilled);
  };
}
