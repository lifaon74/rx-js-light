import { IErrorNotification } from '../../../../../../../misc/notifications/built-in/error/error-notification.type';
import { throwError } from '../../../../../../built-in/from/with-notifications/others/throw-error/throw-error';
import { IObservable } from '../../../../../../type/observable.type';
import { IThenInNotifications, thenObservable } from '../../then-observable';
import { IThenObservableOnFulfilled } from '../../then-observable-on-fulfilled.type';

export type IFulfilledObservableOutNotifications<GOut> =
  GOut
  | IErrorNotification;

export function fulfilledObservable<GInNextValue, GOut>(
  subscribe: IObservable<IThenInNotifications<GInNextValue>>,
  onFulfilled: IThenObservableOnFulfilled<GInNextValue, GOut>,
): IObservable<IFulfilledObservableOutNotifications<GOut>> {
  return thenObservable<GInNextValue, IFulfilledObservableOutNotifications<GOut>>(
    subscribe,
    onFulfilled,
    throwError,
  );
}
