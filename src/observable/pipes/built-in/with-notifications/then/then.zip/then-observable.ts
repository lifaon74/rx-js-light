import { IDefaultNotificationsUnion } from '../../../../../misc/notifications/default-notifications-union.type';
import { IGenericNotification } from '../../../../../misc/notifications/notification.type';
import { IObserver } from '../../../../../observer/type/observer.type';
import { toPromiseLast } from '../../../../built-in/to/with-notifications/promise/last/to-promise-last';
import { IObservable, IUnsubscribe } from '../../../../type/observable.type';
import { IThenObservableOnFulfilled } from './then-observable-on-fulfilled.type';
import { IThenObservableOnRejected } from './then-observable-on-rejected.type';

export type IThenInNotifications<GInNextValue> =
  IDefaultNotificationsUnion<GInNextValue>
  | IGenericNotification
  ;

export function thenObservable<GInNextValue, GOut>(
  subscribe: IObservable<IThenInNotifications<GInNextValue>>,
  onFulfilled: IThenObservableOnFulfilled<GInNextValue, GOut>,
  onRejected: IThenObservableOnRejected<GOut>,
): IObservable<GOut> {
  return (emit: IObserver<GOut>): IUnsubscribe => {
    let running: boolean = true;

    const controller: AbortController = new AbortController();
    const signal: AbortSignal = controller.signal;

    let childUnsubscribe: IUnsubscribe;

    toPromiseLast<GInNextValue>(subscribe, { signal })
      .then(
        (value: GInNextValue) => {
          if (running) {
            childUnsubscribe = onFulfilled(value)(emit);
          }
        },
        (error: any) => {
          if (running) { //  && !isAbortErrorWithSignal(error, signal) => not required
            childUnsubscribe = onRejected(error)(emit);
          }
        },
      );

    return (): void => {
      if (running) {
        running = false;
        controller.abort();
        if (childUnsubscribe !== void 0) {
          childUnsubscribe();
        }
      }
    };
  };
}



