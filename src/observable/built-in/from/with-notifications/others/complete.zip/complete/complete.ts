import { STATIC_COMPLETE_NOTIFICATION } from '../../../../../../misc/notifications/built-in/complete/complete-notification.constant';
import { ICompleteNotification } from '../../../../../../misc/notifications/built-in/complete/complete-notification.type';
import { createNextNotification } from '../../../../../../misc/notifications/built-in/next/create-next-notification';
import { INextNotification } from '../../../../../../misc/notifications/built-in/next/next-notification.type';
import { IObservable } from '../../../../../type/observable.type';
import { fromArray } from '../../../without-notifications/iterable/from-array/from-array';

export type IObservableCompleteNotifications<GValue> =
  INextNotification<GValue>
  | ICompleteNotification
  ;

export function complete<GValue>(
  ...values: readonly GValue[]
): IObservable<IObservableCompleteNotifications<GValue>> {
  return fromArray<IObservableCompleteNotifications<GValue>>([
    ...values.map((value: GValue): INextNotification<GValue> => {
      return createNextNotification(value);
    }),
    STATIC_COMPLETE_NOTIFICATION,
  ]);
}
