import { IMulticastSource } from '../multicast-source/multicast-source';


export interface IReplayLastSource<GValue> extends IMulticastSource<GValue> {
  getValue(): GValue;
}


