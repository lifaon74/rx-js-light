import { createMulticastSource } from '../multicast-source/create-multicast-source';
import { IReplayLastSource } from './replay-last-source';
import { IEmitFunction } from '../../types/emit-function/emit-function';
import { ISubscribeFunction, IUnsubscribeFunction } from '../../types/subscribe-function/subscribe-function';
import { IMulticastSource } from '../multicast-source/multicast-source';


export function createReplayLastSource<GValue>(
  currentValue: GValue,
): IReplayLastSource<GValue> {
  const source: IMulticastSource<GValue> = createMulticastSource<GValue>(true);

  const emit: IEmitFunction<GValue> = (value: GValue) => {
    currentValue = value;
    source.emit(value);
  };

  const subscribe: ISubscribeFunction<GValue> = (emit: IEmitFunction<GValue>): IUnsubscribeFunction => {
    emit(currentValue);
    return source.subscribe((_value: GValue) => {
      currentValue = _value;
      emit(_value);
    });
  };

  return Object.freeze({
    ...source,
    subscribe,
    getValue: (): GValue => {
      return currentValue;
    },
  });
}

// export function createReplayLastSource<GValue>(
//   value: GValue,
// ): IReplayLastSource<GValue> {
//   const source: IMulticastSource<GValue> = createMulticastSource<GValue>(true);
//
//   const subscribe: ISubscribeFunction<GValue> = (emit: IEmitFunction<GValue>): IUnsubscribeFunction => {
//     emit(value);
//     return source.subscribe((_value: GValue) => {
//       value = _value;
//       emit(_value);
//     });
//   };
//
//   return Object.freeze({
//     ...source,
//     subscribe,
//     getValue: (): GValue => {
//       return value;
//     },
//   });
// }

