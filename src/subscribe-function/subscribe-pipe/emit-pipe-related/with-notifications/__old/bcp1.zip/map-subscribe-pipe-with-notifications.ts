import { IMapFunction, mapEmitPipe } from '../../../../pipes/map-emit-pipe';
import {
  emitPipeToSubscribePipeWithNotifications, IEmitPipeToSubscribePipeInValue,
  IEmitPipeToSubscribePipeNotificationsConstraint, IEmitPipeToSubscribePipeWithNotificationsReturn
} from './emit-pipe-to-subscribe-pipe-with-notification';


/**
 * @see mapEmitPipe
 */
export function mapSubscribePipeWithNotifications<// generics
  GInNotificationsUnion extends IEmitPipeToSubscribePipeNotificationsConstraint,
  GOutValue
  //
  >(
  mapFunction: IMapFunction<IEmitPipeToSubscribePipeInValue<GInNotificationsUnion>, GOutValue>,
): IEmitPipeToSubscribePipeWithNotificationsReturn<GInNotificationsUnion, GOutValue> {
  return emitPipeToSubscribePipeWithNotifications<GInNotificationsUnion, GOutValue>(
    mapEmitPipe<IEmitPipeToSubscribePipeInValue<GInNotificationsUnion>, GOutValue>(mapFunction),
  );
}

// export function mapSubscribePipeWithNotifications<GIn, GOut>(
//   mapFunction: IMapFunction<GIn, GOut>,
// ): ISubscribePipeFunction<IEmitPipeToSubscribePipeInNotifications<GIn>, IEmitPipeToSubscribePipeOutNotifications<GOut>> {
//   return emitPipeToSubscribePipeWithNotifications<GIn, GOut>(mapEmitPipe<GIn, GOut>(mapFunction));
// }
