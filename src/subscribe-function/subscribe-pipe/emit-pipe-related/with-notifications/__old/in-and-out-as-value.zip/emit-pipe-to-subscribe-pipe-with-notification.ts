import { IDefaultNotificationsUnion } from '../../../../misc/notifications/default-notifications-union.type';
import { IEmitPipeFunction } from '../../../../types/emit-pipe-function/emit-pipe-function.type';
import { ISubscribePipeFunction } from '../../../../types/subscribe-pipe-function/subscribe-pipe-function.type';
import { ISubscribeFunction, IUnsubscribeFunction } from '../../../../types/subscribe-function/subscribe-function.type';
import { IEmitFunction } from '../../../../types/emit-function/emit-function.type';
import { createNextNotification } from '../../../../misc/notifications/built-in/next/create-next-notification';
import { INextNotification } from '../../../../misc/notifications/built-in/next/next-notification.type';
import { fromUnion, toUnion, Union, UnionMerge } from '../../../../misc/types/union.type';
import { IGenericNotification } from '../../../../misc/notifications/notification.type';


export type IEmitPipeToSubscribePipeInNotifications<GInValue> = UnionMerge<Union<INextNotification<GInValue>>, Union<IGenericNotification>>;

export type IEmitPipeToSubscribePipeOutNotifications<GOutValue> = IDefaultNotificationsUnion<GOutValue>;

export type IEmitPipeToSubscribePipeWithNotificationsReturn<// generics
  GInValue,
  GOutValue,
  //
  > = ISubscribePipeFunction<IEmitPipeToSubscribePipeInNotifications<GInValue>, IEmitPipeToSubscribePipeOutNotifications<GOutValue>>;

/**
 * Converts an emit pipe function to a subscribe pipe function
 */
export function emitPipeToSubscribePipeWithNotifications<// generics
  GInValue,
  GOutValue,
  //
  >(
  emitPipeFunction: IEmitPipeFunction<GInValue, GOutValue>,
): IEmitPipeToSubscribePipeWithNotificationsReturn<GInValue, GOutValue> {
  type GInNotificationsUnion = IEmitPipeToSubscribePipeInNotifications<GInValue>;
  type GOutNotificationsUnion = IEmitPipeToSubscribePipeOutNotifications<GOutValue>;

  return (subscribe: ISubscribeFunction<GInNotificationsUnion>): ISubscribeFunction<GOutNotificationsUnion> => {
    return (emit: IEmitFunction<GOutNotificationsUnion>): IUnsubscribeFunction => {

      const next: IEmitFunction<GInValue> = emitPipeFunction((value: GOutValue) => {
        emit(toUnion(createNextNotification<GOutValue>(value)));
      });

      return subscribe((notificationsUnion: GInNotificationsUnion) => {
        const notification: IGenericNotification = fromUnion(notificationsUnion);
        switch (notification.name) {
          case 'next':
            next(notification.value);
            break;
          case 'complete':
          case 'error':
            emit(notificationsUnion as GOutNotificationsUnion);
            break;
        }
      });
    };
  };
}
