import { IMapFunction, mapEmitPipe } from '../../../../pipes/map-emit-pipe';
import {
  emitPipeToSubscribePipeWithNotifications, IEmitPipeToSubscribePipeWithNotificationsReturn
} from './emit-pipe-to-subscribe-pipe-with-notification';


/**
 * @see mapEmitPipe
 */
export function mapSubscribePipeWithNotifications<// generics
  GInValue,
  GOutValue,
  //
  >(
  mapFunction: IMapFunction<GInValue, GOutValue>,
): IEmitPipeToSubscribePipeWithNotificationsReturn<GInValue, GOutValue> {
  return emitPipeToSubscribePipeWithNotifications<GInValue, GOutValue>(
    mapEmitPipe<GInValue, GOutValue>(mapFunction),
  );
}
