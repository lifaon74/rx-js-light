export function toCSSPercent(
  value: number,
): string {
  return `${value}%`;
}

