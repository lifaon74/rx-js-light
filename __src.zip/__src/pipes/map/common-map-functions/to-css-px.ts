export function toCSSPx(
  value: number,
): string {
  return `${value}px`;
}

