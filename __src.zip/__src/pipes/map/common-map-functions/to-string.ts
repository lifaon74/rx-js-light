export function toString(
  value: unknown,
): string {
  return String(value);
}

