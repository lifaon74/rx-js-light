export function toNumber(
  value: unknown,
): number {
  return Number(value);
}

