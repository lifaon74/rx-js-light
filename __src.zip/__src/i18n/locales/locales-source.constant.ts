import { createLocalesSource } from './create-locales-source';

export const LOCALES = createLocalesSource();
