export interface IAbortTimer {
  (): void;
}

