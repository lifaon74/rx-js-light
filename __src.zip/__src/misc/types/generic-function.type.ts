export interface IGenericFunction {
  (...args: any[]): any;
}

