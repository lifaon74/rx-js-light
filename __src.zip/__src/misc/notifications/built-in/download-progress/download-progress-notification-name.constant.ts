export const DOWNLOAD_PROGRESS_NOTIFICATION_NAME = 'download-progress';
