export const ERROR_NOTIFICATION_NAME = 'error';
