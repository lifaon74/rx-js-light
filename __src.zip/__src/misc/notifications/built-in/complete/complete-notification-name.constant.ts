export const COMPLETE_NOTIFICATION_NAME = 'complete';
