import { INotification } from '../../notification.type';

export type ICompleteNotification = INotification<'complete', void>;
