export const EMPTY_ERROR_NAME = 'EmptyError';
