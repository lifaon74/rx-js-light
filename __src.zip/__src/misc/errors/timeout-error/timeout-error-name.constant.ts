export const TIMEOUT_ERROR_NAME = 'TimeoutError';
