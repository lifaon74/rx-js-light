export const NETWORK_ERROR_NAME = 'NetworkError';
