export const LOCK_ERROR_NAME = 'LockError';
