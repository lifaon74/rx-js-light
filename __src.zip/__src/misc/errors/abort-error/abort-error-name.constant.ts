export const ABORT_ERROR_NAME = 'AbortError';
