
- [the rxjs documentation](https://rxjs-dev.firebaseapp.com/guide/observable)
- [excellent tutorial](https://gist.github.com/staltz/868e7e9bc2a7b8c1f754)

