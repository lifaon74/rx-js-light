https://raw.githubusercontent.com/vitejs/vite/main/packages/vite/CHANGELOG.md

https://github.com/conventional-changelog/conventional-changelog/tree/master/packages/conventional-changelog-cli

https://www.conventionalcommits.org/en/v1.0.0/
https://github.com/angular/angular/blob/22b96b9/CONTRIBUTING.md#-commit-message-guidelines

https://github.com/conventional-changelog/standard-version

## [1.0.0](https://github.com/lifaon74/rx-js-light/compare/v1.0.0...v1.0.0) (2021-01-30)

### Bug Fixes

* fix types
  errors ([#2726](https://github.com/vitejs/vite/issues/2726)) ([9716582](https://github.com/vitejs/vite/commit/97165828ecbcea867e927c62033002359d83a0db))

### Features

* **dev:** support keepNames option for optimizeDependencies
  config ([#2742](https://github.com/vitejs/vite/issues/2742)) ([130bf5a](https://github.com/vitejs/vite/commit/130bf5a03af2733dff9a34ef74450740d7cdb991))


